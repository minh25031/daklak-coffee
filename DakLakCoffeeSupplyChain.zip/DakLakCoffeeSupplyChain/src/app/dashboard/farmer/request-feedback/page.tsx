import React from 'react'

function page() {
    return (
        <div>Trang tư vấn</div>
    )
}

export default page