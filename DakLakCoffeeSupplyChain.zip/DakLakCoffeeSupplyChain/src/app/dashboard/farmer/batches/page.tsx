import React from 'react'

function Batches() {
    return (
        <div>Lô Caffe</div>
    )
}

export default Batches