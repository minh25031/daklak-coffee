export const roleSlugMap: Record<string, string> = {
  Admin: "admin",
  BusinessManager: "manager",
  BusinessStaff: "staff", 
  Farmer: "farmer",
  AgriculturalExpert: "expert",
  DeliveryStaff: "delivery", 
};
