export default function Footer() {
  return (
    <footer className="text-center text-sm py-4 border-t text-gray-500">
      © 2025 DakLak SupplyChain Platform. All rights reserved.
    </footer>
  );
}
