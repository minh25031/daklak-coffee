(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c5746a0f._.js",
  "static/chunks/src_89f5e1b1._.js",
  "static/chunks/src_styles_globals_92af3bb9.css"
],
    source: "dynamic"
});
