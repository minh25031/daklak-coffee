(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a003c024._.js",
  "static/chunks/src_0590b4e8._.js"
],
    source: "dynamic"
});
