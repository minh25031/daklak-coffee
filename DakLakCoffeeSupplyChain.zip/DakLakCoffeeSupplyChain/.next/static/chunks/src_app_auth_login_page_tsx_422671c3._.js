(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3bd4171d._.js",
  "static/chunks/src_6ee26800._.js"
],
    source: "dynamic"
});
